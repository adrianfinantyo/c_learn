#include <stdio.h>

int main()
{
	int number = 14026;
	
	printf ("Content of number = %d\n", number);
	printf ("Address of number = %p\n", &number);
	
	return 0;
}
